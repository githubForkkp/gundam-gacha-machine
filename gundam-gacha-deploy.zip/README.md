# 高达扭蛋机 (Gundam Gacha Machine)

一个基于Web的高达主题扭蛋机游戏，使用HTML5、CSS3和JavaScript开发。

## 功能特性

- 🎮 高达主题扭蛋机游戏
- 🎯 单次抽取和十连抽取功能
- 🏪 个人机库管理
- 📊 游戏统计系统
- ⚙️ 游戏设置面板
- 🎵 音效和背景音乐
- 📱 响应式设计，支持移动端

## 技术栈

- HTML5
- CSS3 (Tailwind CSS)
- JavaScript (ES6+)
- 像素风格UI设计

## 本地运行

1. 克隆或下载项目文件
2. 在浏览器中打开 `index.html`
3. 开始游戏！

## 部署

本项目可以部署到任何静态网站托管服务上，如：
- GitHub Pages
- Netlify
- Vercel
- Claw.cloud

## 游戏说明

- 初始代币：1000
- 单次抽取：100代币
- 十连抽取：1000代币
- 支持每日签到获得额外代币
- 收集各种高达机体

## 许可证

MIT License 