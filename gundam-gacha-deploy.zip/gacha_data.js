export const prizePool = [
    {
        id: 'ssr001',
        name: 'ν高达',
        model: 'RX-93',
        rarity: 'SSR',
        image_url: 'https://r2.flowith.net/files/o/1751696109477-rx-93_nu_gundam_ssr_pixel_art_index_9@1024x1024.png'
    },
    {
        id: 'ssr002',
        name: '强袭自由高达',
        model: 'ZGMF-X20A',
        rarity: 'SSR',
        image_url: 'https://r2.flowith.net/files/o/1751696115609-pixel_art_sprite_for_strike_freedom_gundam_game_prize_pool_index_10@1024x1024.png'
    },
    {
        id: 'ssr003',
        name: '独角兽高达',
        model: 'RX-0',
        rarity: 'SSR',
        image_url: 'https://r2.flowith.net/files/o/1751696109477-rx-93_nu_gundam_ssr_pixel_art_index_9@1024x1024.png'
    },
    {
        id: 'sr001',
        name: '夏亚专用扎古II',
        model: 'MS-06S',
        rarity: 'SR',
        image_url: 'https://r2.flowith.net/files/o/1751696120089-pixel_art_char_zaku_ii_index_7@1024x1024.png'
    },
    {
        id: 'sr002',
        name: '飞翼高达',
        model: 'XXXG-01W',
        rarity: 'SR',
        image_url: 'https://r2.flowith.net/files/o/1751696127880-wing_gundam_sr_pixel_art_prize_index_8@1024x1024.png'
    },
    {
        id: 'sr003',
        name: '命运高达',
        model: 'ZGMF-X42S',
        rarity: 'SR',
        image_url: 'https://r2.flowith.net/files/o/1751696120089-pixel_art_char_zaku_ii_index_7@1024x1024.png'
    },
    {
        id: 'sr004',
        name: '无限正义高达',
        model: 'ZGMF-X19A',
        rarity: 'SR',
        image_url: 'https://r2.flowith.net/files/o/1751696127880-wing_gundam_sr_pixel_art_prize_index_8@1024x1024.png'
    },
    {
        id: 'r001',
        name: '高达（元祖）',
        model: 'RX-78-2',
        rarity: 'R',
        image_url: 'https://r2.flowith.net/files/o/1751696094800-rx-78-2_gundam_pixel_art_prize_pool_index_5@1024x1024.png'
    },
    {
        id: 'r002',
        name: '沙扎比',
        model: 'MSN-04',
        rarity: 'R',
        image_url: 'https://r2.flowith.net/files/o/1751696104962-msn-04_sazabi_pixel_art_prize_pool_index_6@1024x1024.png'
    },
    {
        id: 'r003',
        name: 'Z高达',
        model: 'MSZ-006',
        rarity: 'R',
        image_url: 'https://r2.flowith.net/files/o/1751696094800-rx-78-2_gundam_pixel_art_prize_pool_index_5@1024x1024.png'
    },
    {
        id: 'r004',
        name: 'ZZ高达',
        model: 'MSZ-010',
        rarity: 'R',
        image_url: 'https://r2.flowith.net/files/o/1751696104962-msn-04_sazabi_pixel_art_prize_pool_index_6@1024x1024.png'
    },
    {
        id: 'n001',
        name: '吉姆',
        model: 'RGM-79',
        rarity: 'N',
        image_url: 'https://r2.flowith.net/files/o/1751696097527-pixel_art_gm_prize_pool_asset_index_3@1024x1024.png'
    },
    {
        id: 'n002',
        name: '扎古II（量产型）',
        model: 'MS-06',
        rarity: 'N',
        image_url: 'https://r2.flowith.net/files/o/1751696104574-pixel_art_zaku_ii_prize_pool_art_index_4@1024x1024.png'
    },
    {
        id: 'n003',
        name: '吉姆II',
        model: 'RGM-79R',
        rarity: 'N',
        image_url: 'https://r2.flowith.net/files/o/1751696097527-pixel_art_gm_prize_pool_asset_index_3@1024x1024.png'
    },
    {
        id: 'n004',
        name: '扎古III',
        model: 'MS-09',
        rarity: 'N',
        image_url: 'https://r2.flowith.net/files/o/1751696104574-pixel_art_zaku_ii_prize_pool_art_index_4@1024x1024.png'
    }
];

export const prizePoolById = prizePool.reduce((acc, item) => {
    acc[item.id] = item;
    return acc;
}, {});
